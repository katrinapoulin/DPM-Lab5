package ca.mcgill.ecse211.localizer;
import ca.mcgill.ecse211.lab5.lab5;
import ca.mcgill.ecse211.odometer.Odometer;
import ca.mcgill.ecse211.odometer.OdometerExceptions;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;

public class UltrasonicLocalizer {
	
	private static final int ROTATE_SPEED = 75;
  	private EV3LargeRegulatedMotor leftMotor;
  	private EV3LargeRegulatedMotor rightMotor;
  	Odometer odo;
  	//private Navigation nav;
  	private float[] usData;
  	private SampleProvider us;
  	
  	private int filterControl = 0;
  	private int filterOut = 10;
  	private float lastDistance = 0;
  	
  	//private static final int d = 29; 
	//private static final int k = 4;
	//private static final int NOT_FACING_WALL = 3;
  	
  	public static final double WHEEL_RAD=2.1;
  	public static final double TRACK = 13.5;
  	
	double angle1, angle2, origin;
  	
	/**
	 * This constructor creates an ultrasonic localization object that can travel to the origin
	 * @param odo Odometer used 
	 * @param leftMotor Left motor of the robot
	 * @param rightMotor Right motor of the robot
	 * @param us Ultrasonic sensor
	 * @param usData Buffer for ultrasonic sensor data
	 * @param edgeType Falling/Rising Edge (Falling=1, Rising=2)
	 * @throws OdometerExceptions
	 */
  	public UltrasonicLocalizer(Odometer odo,  SampleProvider us, float [] usData) throws OdometerExceptions {
  		
  		this.odo = Odometer.getOdometer(); //get current odo
  		this.leftMotor = lab5.leftmotor;//left, right motors
  		this.rightMotor = lab5.rightmotor;
  		this.us = us;//sensor
  		this.usData = usData;//sensor buffer
  	}
  	
  	/**
  	 * The method localizeUS takes the position of the robot and sweeps for a change in the wall distance, depending on the edge type
  	 * @param type Falling or Rising Edge
  	 */
  	public void localizeUS() {
  		
  		//setup motor speed
  		leftMotor.setSpeed(ROTATE_SPEED);
  		rightMotor.setSpeed(ROTATE_SPEED);
  	
  		//fallingEdge();//do falling edge
  		risingEdge();
  		
  	}
  	/**
  	 * The method falling Edge is used when the robot is NOT facing the wall. In that case, it will check for a reduction of distance and sweep for angle
  	 */
  	public void fallingEdge() {
  		
  		
  		while(getData() < 30) {//while distance is below 30cm (if the robot is not well located)
  			
  			rightMotor.backward();//rotate
  			leftMotor.forward();
  		}
		
  		while(getData() > 30) {//then, while distance stays over 30cm
  			
  			rightMotor.backward();//still rotate
  			leftMotor.forward();
  			
  		}
  		
  		rightMotor.stop(true);//still rotate
		leftMotor.stop();
  		
  		angle1 = (odo.getXYT())[2];//note angle
  		

  		while(getData() < 30) {//keep rotating in the other way
  			
  			rightMotor.forward();
  			leftMotor.backward();
  		}
  		
  		rightMotor.rotate(50,true);//still rotate
		leftMotor.rotate(-50);
  		
  		while(getData() > 30) {
  			
  			rightMotor.forward();			
  			leftMotor.backward();
  		}
  		
  		leftMotor.stop(true);
  		rightMotor.stop();
  		
  		angle2 = (odo.getXYT())[2];//get second angle
  		double angle_correction;
  		if(angle1<angle2) {						//calculate correction angle
			angle_correction = (225-(angle1 + angle2)/2);		//225 needs to be tested
		}else {
			angle_correction = (45 - (angle1 + angle2)/2);	//45 needs to be tested
		}
		
		odo.setTheta(odo.getXYT()[2]+angle_correction);			//update odometer
  		turnTo(0);
  		
  	}
  	
  	public void risingEdge() {
 		 
 		 while(getData() > 30) {//while distance is over 30, just in case
 			
 			rightMotor.backward();//rotate
 			leftMotor.forward();
 		}
 		
 		while(getData() < 30) {//if distance is below 30 (we are facing a wall)
 			
 			rightMotor.backward();
 			leftMotor.forward();
 			
 		}
 		
 		angle1 = (odo.getXYT())[2];//get angle
 		
 		while(getData() > 30) {
 			
 			rightMotor.forward();//rotate until we see a wall
 			leftMotor.backward();
 		}
 		
 		while(getData() < 30) {//rotate until we do not see a wall anymore
 			
 			rightMotor.forward();
 			leftMotor.backward();
 		}
 		
 		leftMotor.stop(true);
 		rightMotor.stop();
 		
 		angle2 = (odo.getXYT())[2];//note angle
 		
 		double angle_correction;
  		if(angle1<angle2) {						//calculate correction angle
			angle_correction = (225-(angle1 + angle2)/2);		//225 needs to be tested
		}else {
			angle_correction = (45 - (angle1 + angle2)/2);	//45 needs to be tested
		}
		double correct_angle = odo.getXYT()[2]+angle_correction+180;
		if(correct_angle>360) {
			correct_angle = correct_angle - 360;
		}
		odo.setTheta(correct_angle-15);			//update odometer
  		turnTo(0);
 		 
 	 }
  	/*
  	public void risingEdge() {
		double theta_left = 0, theta_to225 = 0;

		while(getData() > NOT_FACING_WALL) {		// We check if it is not facing a wall
			leftMotor.backward();					// In that case we rotate until we find one
			rightMotor.forward();
		}

		while(true) {									// Then we start the method, we rotate until we find a rising edge

			leftMotor.forward();
			rightMotor.backward();

			if(aboveTheshold()) {						// When we do, we stop and set theta to 0
				leftMotor.stop(true);
				rightMotor.stop(false);
				break;
			}
		}

		odo.setTheta(0);

		try {											// We also sleep the sensor for 2000ms for the device to be far from the first point before resuming detection
			leftMotor.backward();
			rightMotor.forward();
			UltrasonicPoller.sleep(2000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		while(true) {									// Then when we find our 2nd point, we stop, get the theta we traveled and find the theta by which we need to rotate

			leftMotor.backward();
			rightMotor.forward();

			if(aboveTheshold()) {
				leftMotor.stop(true);
				rightMotor.stop(false);
				theta_left = odo.getXYT()[2];
				break;
			}
		}

		theta_to225 = 0.5 *theta_left;

		leftMotor.rotate(convertAngle(WHEEL_RAD, TRACK, theta_to225), true);			// We rotate by the amount needed to get to the 225 degree orientation
		rightMotor.rotate(-convertAngle(WHEEL_RAD, TRACK, theta_to225), false);

		leftMotor.rotate(convertAngle(WHEEL_RAD, TRACK, Math.toRadians(135)), true);	// Finally we rotate 135 degrees to get to the 0 degrees direction
		rightMotor.rotate(-convertAngle(WHEEL_RAD, TRACK, Math.toRadians(135)), false);

		leftMotor.stop(true);
		leftMotor.stop(false);
		odo.setTheta(0);

		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
  	
  	private boolean aboveTheshold() {
		return (getData() > d + k);
	}*/
  		
  	/**
  	 * The method falling Edge is used when the robot is facing the wall. In that case, it will check for an increase of distance and sweep for angle
  	 */
  	
  	 /**
  	  * The method getData gets the distance from ultrasonic sensor
  	  * @return
  	  */
  	 public float getData() {

  			us.fetchSample(usData, 0);
  			float distance = (int)(usData[0]*100.0);
  			float result = 0;
  			if (distance > 50 && filterControl < filterOut) {
  				// bad value, do not set the distance var, however increment the filter value
  				filterControl ++;
  				result = lastDistance;
  			} else if (distance > 255){
  				// true 255, therefore set distance to 255
  				result = 50; //clips it at 50
  			} else {
  				// distance went below 255, therefore reset everything.
  				filterControl = 0;
  				result = distance;
  			}
  			lastDistance = distance;
  			
  			return result;
  		}
  	 
  	 
  	 
  	 /**
  	  * the method turnTo turns to the right angle form a given odo angle
  	  * @param theta Angle we want to be turning of
  	  */
  	public void turnTo(double theta) {

			leftMotor.rotate(convertAngle(WHEEL_RAD, TRACK , theta), true);
			rightMotor.rotate(-convertAngle(WHEEL_RAD, TRACK, theta), false);
		}
  	
  	/**Converts the angle to turn of to a distance so it is easier to use with the rotate mathod of the motors.*/
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	/**Converts the distance to turn of to a rotating distance so it is easier to use with the rotate mathod of the motors.*/
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
}
