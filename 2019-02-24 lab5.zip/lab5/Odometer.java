/**
 * This class is the odometer
 * 
 * @author Alfred Wang
 * 
 */
package ca.mcgill.ecse211.lab5;


import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Odometer extends OdometerData implements Runnable {

  private OdometerData odoData;
  private static Odometer odo = null; // Returned as singleton

  // Motors and related variables
  private int leftMotorTachoCount;
  private int rightMotorTachoCount;
  private EV3LargeRegulatedMotor leftMotor;
  private EV3LargeRegulatedMotor rightMotor;

  private final double TRACK;
  private final double WHEEL_RAD;

  //private double[] position;

  private double theta;
  //private double x_value;
  //private double y_value;
  private int old_lmtc = 0;
  private int old_rmtc = 0;
  private double displacement_L, displacement_R;
  

  private static final long ODOMETER_PERIOD = 25; // odometer update period in ms

  /**
   * This is the default constructor of this class. It initiates all motors and variables once.It
   * cannot be accessed externally.
   * 
   * @param leftMotor
   * @param rightMotor
   * @throws OdometerExceptions
   */
  public Odometer(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
      final double TRACK, final double WHEEL_RAD) throws OdometerExceptions {
    odoData = OdometerData.getOdometerData(); // Allows access to x,y,z
                                              // manipulation methods
    this.leftMotor = leftMotor;
    this.rightMotor = rightMotor;

    // Reset the values of x, y and z to 0
    odoData.setXYT(0, 0, 0);

    this.leftMotorTachoCount = 0;
    this.rightMotorTachoCount = 0;

    this.TRACK = TRACK;
    this.WHEEL_RAD = WHEEL_RAD;

  }

  /**
   * This method is meant to ensure only one instance of the odometer is used throughout the code.
   * 
   * @param leftMotor
   * @param rightMotor
   * @return new or existing Odometer Object
   * @throws OdometerExceptions
   */
  public synchronized static Odometer getOdometer(EV3LargeRegulatedMotor leftMotor,
      EV3LargeRegulatedMotor rightMotor, final double TRACK, final double WHEEL_RAD)
      throws OdometerExceptions {
    if (odo != null) { // Return existing object
      return odo;
    } else { // create object and return it
      odo = new Odometer(leftMotor, rightMotor, TRACK, WHEEL_RAD);
      return odo;
    }
  }

  /**
   * This class is meant to return the existing Odometer Object. It is meant to be used only if an
   * odometer object has been created
   * 
   * @return error if no previous odometer exists
   */
  public synchronized static Odometer getOdometer() throws OdometerExceptions {

    if (odo == null) {
      throw new OdometerExceptions("No previous Odometer exits.");

    }
    return odo;
  }

  /**
   * This method is where the logic for the odometer will run. Use the methods provided from the
   * OdometerData class to implement the odometer.
   */
  // run method (required for Thread)
  public void run() {
    long updateStart, updateEnd;

    while (true) {
    	double dx, dy, dt, angle, dd;
    	
      updateStart = System.currentTimeMillis();

      leftMotorTachoCount = leftMotor.getTachoCount();
      rightMotorTachoCount = rightMotor.getTachoCount();

      // TODO Calculate new robot position based on tachometer counts
      displacement_L = Math.PI*WHEEL_RAD*(leftMotorTachoCount - old_lmtc)/180;
      displacement_R = Math.PI*WHEEL_RAD*(rightMotorTachoCount - old_rmtc)/180;
      
      old_lmtc = leftMotorTachoCount;
      old_rmtc = rightMotorTachoCount;
      
      dd = (displacement_L+displacement_R)/2;
      angle = (displacement_L-displacement_R)/TRACK; 
      theta = theta+angle;
      
      dx = Math.sin(theta) * dd;
      dy = Math.cos(theta) * dd;
      dt = angle*180/Math.PI;
      
      // TODO Update odometer values with new calculated values
      
      odo.update(dx, dy, dt);
      
      // this ensures that the odometer only runs once every period
      updateEnd = System.currentTimeMillis();
      if (updateEnd - updateStart < ODOMETER_PERIOD) {
        try {
          Thread.sleep(ODOMETER_PERIOD - (updateEnd - updateStart));
        } catch (InterruptedException e) {
          // there is nothing to be done
        }
      }
    }
  }

  	/**
  	 * This method is used to get the motors of odometer
  	 * @return An array of motor, leftMotor with index 0, rightMotor with index 1
  	 */
  	public EV3LargeRegulatedMotor[] getMotor() {
	  EV3LargeRegulatedMotor[] motors = {leftMotor, rightMotor};
	  return motors;
  	}
  	
  	/**
  	 * This method is used to set motor speed
  	 * @param speed This is the target speed
  	 */
  	public void setMotorSpeeds (int speed) {
	  leftMotor.setSpeed(speed);
	  rightMotor.setSpeed(speed);
  	}
  
  	/**
  	 * This method makes both wheel to go forward
  	 */
  	public void moveforward() {
	  leftMotor.forward();
	  rightMotor.forward();
  	}
  	/**
  	 * This method makes the robot to spin
  	 * @param dir This boolean is used to determine the rotation direction, true for clockwise, false for counterclockwise
  	 */
  	public void spin(boolean dir) {
	  if(dir) {
		  leftMotor.forward();
		  rightMotor.backward();
	  }else {
		  leftMotor.backward();
		  rightMotor.forward();
	  }
  	}
  
  
  
  
  
  
  
  
  
  
}
