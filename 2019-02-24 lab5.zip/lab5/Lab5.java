package ca.mcgill.ecse211.lab5;

import ca.mcgill.ecse211.lab5.Odometer;
import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.motor.EV3MediumRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

/**
 * ECSE 211 Lab 5 Can Searching
 * Group 20
 * 
 * @author Alfred Wang
 *
 * 2019 - 02 - 21
 */

public class Lab5 {
	private static final EV3LargeRegulatedMotor leftmotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));		//left motor
	private static final EV3LargeRegulatedMotor rightmotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B"));		//right motor
	private static final Port usPort = LocalEV3.get().getPort("S1");				//port for ultrasonic sensor
	private static final Port llcolorPort = LocalEV3.get().getPort("S2");			//port for localization color sensor
	private static final Port RcolorPort = LocalEV3.get().getPort("S3");
	public static final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S4")); 					//Light sensor for can color detection
	public static final EV3MediumRegulatedMotor sensorMotor = new EV3MediumRegulatedMotor(LocalEV3.get().getPort("C")); //Light sensor motor
	
	private static final double TRACK = 12.9;						//track of the robot
	private static final double WHEEL_RAD = 2.1;					//wheel radius of the robot
	static Odometer odo ;											//odometer
	private static int detected_color = 4;							//color of the can detected, originally set to 4 (other color)
	
	public static TextLCD lcd = LocalEV3.get().getTextLCD();		//lcd display
	
	static int floorcolor_R;
	static int floorcolor_L;
	static int half_tile = 15;
	static boolean can_detected;
	//-----------------------------------------------------------
	static int LLx = 1;								//lower left x
	static int LLy = 1;								//lower left y
	static int URx = 3;								//upper right x
	static int URy = 3;								//upper right y
	static int TR = 2;					//target color, (0 for blue, 1 for green, 2 for yellow, 3 for red, 4 for other)
	static int SC = 0;
	//-------------------------------------------------------------
	static boolean target_detected = false;			//boolean to know if the target is found
	static boolean skip_cc = false;
	static String[] color_base = {"BLUE", "GREEN", "YELLOW", "RED", "OTHER"};	//color data base
	
	/**
	 * The main method makes the robot to achieve the goal of lab 5, including localization, navigating to LL corner, find the target can and go to UR corner
	 * @param args
	 * @throws OdometerExceptions
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws OdometerExceptions, InterruptedException {
		
		@SuppressWarnings("resource")			//ultrasonic sensor will always be used, no need to turn it off
		SensorModes usSensor = new EV3UltrasonicSensor(usPort);				//get the ultrasonic sensor
		SampleProvider usValue = usSensor.getMode("Distance");			
		float[] usData = new float[usValue.sampleSize()];	
		
		@SuppressWarnings("resource")			//localization light sensor will always be used, no need to turn it off
		SensorModes llcolorSensor = new EV3ColorSensor(llcolorPort);		//get the color sensor
		SampleProvider colorValue = llcolorSensor.getMode("Red");
		float[] colorData = new float[colorValue.sampleSize()];		
		
		@SuppressWarnings("resource")
		SensorModes RcolorSensor = new EV3ColorSensor(RcolorPort);		//get the color sensor
		SampleProvider RcolorValue = RcolorSensor.getMode("Red");
		float[] RcolorData = new float[RcolorValue.sampleSize()];		
		
		floorcolor_R = getLightData(RcolorValue,RcolorData);
		floorcolor_L = getLightData(colorValue,colorData);
		
		odo = Odometer.getOdometer(leftmotor, rightmotor, TRACK, WHEEL_RAD); 		//get odometer
		
		leftmotor.setAcceleration(200);
		rightmotor.setAcceleration(200);
		
		lcd.drawString("Press to start", 0, 1);
		Button.waitForAnyPress();					//wait for press to start
	    
	    Thread odoThread = new Thread(odo);							//start the odometer
	    odoThread.start();
	    
	    
	    UltrasonicLocalizer usl = new UltrasonicLocalizer (odo, leftmotor, rightmotor, usValue, usData, 1);
	    usl.localizeUS(1);
    	lcd.drawString("Finished US Localization", 0, 3);
	    turnTo(0);												//turn to 0 degree	

	    turnTo(200);
	    LightLocalizer lsl = new LightLocalizer (odo, colorValue, colorData);		//use light(color) sensor to localize
	    lsl.Localize();
	    travelTo(0,0,false);								//travel to 0,0
	    turnTo(0);											//turn to 0
	    correct_odo(SC);
	    
	    lcd.drawString("Finished CS Localization", 0, 4);
	    Thread.sleep(1000);
	    lcd.clear();
	    //navigation in the searching area starts----------------------------------------------------------------------------------------------------------
	    lcd.drawString("Press to start", 0, 1);
	    Button.waitForAnyPress();
	    travelTo_LL(SC,LLx,LLy);
	    turnTo(0);
	    //odo.setXYT(LLx*30.48,LLy*30.48, 0);
	    
	    final UltrasonicPoller myusData = new UltrasonicPoller(usValue);
	    myusData.start();
	    SensorData mylsData = new SensorData();
		mylsData.start();
		LightSensorCalibration lscData = new LightSensorCalibration(colorValue,colorData,RcolorValue,RcolorData);
		Thread.sleep(1000);
		
	    for(int i = 0;i<=URx-LLx;i++) {								
	    	if(i%2==1) {
	    		for(int m=URy-LLy;m>=0;m--) {
	    			detect_can(myusData, lscData, mylsData, i, m);
	    			if(target_detected) break;
	    		}
	    	}else {
	    		for(int m=0;m<=URy-LLy;m++) {
	    			detect_can(myusData, lscData, mylsData,i, m);
	    			if(target_detected) break;
	    		}
	    	}
	    	if(target_detected) {
	    		lcd.drawString("target found", 0, 4);
	    	    break;
	    	}
	    }
	    
	    
	    leftmotor.stop(true);
	    rightmotor.stop();
	    
	    travel_to_UR();
	    //not finished, still need to travel to the UR corner
	    
	    Button.waitForAnyPress();
	    System.exit(0);
	    
	}
	
	public static void travelTo_LL(int SC, int LLx, int LLy) {
		if(SC == 0) {
			travelTo(LLx*30.48, LLy*30.48, false);
		}else if(SC == 1) {
			travelTo(odo.getXYT()[0], LLy*30.48-half_tile, false);
			travelTo(LLx*30.48, LLy*30.48-half_tile, false);
			travelTo(LLx*30.48, LLy*30.48, false);
		}else if(SC == 2) {
			travelTo(odo.getXYT()[0]+half_tile,odo.getXYT()[1], false);
			travelTo(odo.getXYT()[0], LLy*30.48-half_tile, false);
			travelTo(LLx*30.48, odo.getXYT()[1], false);
			travelTo(LLx*30.48, LLy*30.48, false);
		}else {
			travelTo(LLx*30.48-half_tile,odo.getXYT()[1], false);
			travelTo(LLx*30.48-half_tile, LLy*30.48, false);
			travelTo(LLx*30.48, LLy*30.48, false);
		}
	}
	
	public static void correct_odo(int SC) {
		if(SC==0) {
			odo.setXYT(1, 1, 0);
		}else if(SC==1) {
			odo.setXYT(7, 0, 270);
		}else if(SC==2) {
			odo.setXYT(7, 7, 180);
		}else {
			odo.setXYT(0, 7, 90);
		}
	}
	
	public static void travel_to_UR() {
		
		leftmotor.rotate(-convertDistance(WHEEL_RAD,5),true);
		rightmotor.rotate(-convertDistance(WHEEL_RAD,5),false);
		travelTo(odo.getXYT()[0]+15,odo.getXYT()[1],false);
		travelTo(odo.getXYT()[0],URy*30.48-15,false);
		travelTo(URx*30.48-15,odo.getXYT()[1],false);
		travelTo(URx,URy,false);
	}
	
	/**
	 * 
	 * This method is used to detect whether or not there is a can in front of the robot
	 * 
	 * @param myData This is the ultrasonic sensor data provider
	 * @param mylsData This is the light sensor data provider
	 * @param x This is the x value of target location 
	 * @param y	This is the y value of target location
	 * @throws InterruptedException 
	 */
	
	public static void detect_can(UltrasonicPoller myData, LightSensorCalibration lscData, SensorData mylsData, int x, int y) throws InterruptedException {
		leftmotor.setSpeed(200);
		rightmotor.setSpeed(200);
		leftmotor.setAcceleration(1500);
		leftmotor.setAcceleration(1500);
		can_detected = false;
		if((x==0)&&(y==0)) return;
		travelTo(x*30.48+LLx*30.48,y*30.48+LLy*30.48,true);
		while(leftmotor.isMoving()) {
			int[] colorData = lscData.getLightData();
			if(myData.getDistance()<=5) {				//if the ultrasonic sensor has a reading less than or equal to 5 cm, wo consider that there is a can and the robot stops and scan it
				can_detected = true;
				leftmotor.stop(true);
				rightmotor.stop();
				lcd.clear();
				lcd.drawString("can detected", 0, 1);
				detect_color(mylsData);
				//SensorData mylsData = new SensorData();
				if(detected_color == TR) {		//find out if this is the target can or not
					target_detected = true;
					Sound.beep();							//if yes, beep once
					lcd.drawString("color: "+color_base[detected_color], 0, 2);
					break;
				}else {										//if no, beep twice
					Sound.beep();
					Sound.beep();
					lcd.drawString("color: "+color_base[detected_color], 0, 2);
				}
				
				//go around the can
				avoid_can();
				
			} else if(colorData[0]-floorcolor_L > 100&&colorData[1]-floorcolor_R<100&&!skip_cc){
				leftmotor.stop(true);
				while(lscData.getLightData()[1]-floorcolor_R<100) {
					rightmotor.forward();
					Thread.sleep(50);
				}
				rightmotor.stop();
				calibrate_angle(odo);
				travelTo(x*30.48+LLx*30.48,y*30.48+LLy*30.48,true);
				
			}else if(colorData[0]-floorcolor_L < 100&&colorData[1]-floorcolor_R>100&&!skip_cc) {
				rightmotor.stop(true);
				while(lscData.getLightData()[0]-floorcolor_R<100) {
					leftmotor.forward();
					Thread.sleep(50);
				}
				leftmotor.stop();
				calibrate_angle(odo);
				travelTo(x*30.48+LLx*30.48,y*30.48+LLy*30.48,true);
			}
			Thread.sleep(50);
		}
		if(can_detected) {
			skip_cc = true;
		}else {
			skip_cc = false;
		}
		
	}

	public static void avoid_can() {
		leftmotor.rotate(-convertDistance(WHEEL_RAD,5),true);
		rightmotor.rotate(-convertDistance(WHEEL_RAD,5),false);
		leftmotor.rotate(convertAngle(WHEEL_RAD,TRACK,90),true);
		rightmotor.rotate(-convertAngle(WHEEL_RAD,TRACK,90),false);
		leftmotor.rotate(convertDistance(WHEEL_RAD,15),true);
		rightmotor.rotate(convertDistance(WHEEL_RAD,15),false);
	}
	
	public static void calibrate_angle(Odometer odo) {
		int angle = (int) odo.getXYT()[2];
		if(angle<45||angle>315) {
			odo.setTheta(0);
		}else if(angle>=45&&angle<=135) {
			odo.setTheta(90);
		}else if(angle>135&&angle<225) {
			odo.setTheta(180);
		}else {
			odo.setTheta(270);
		}
	}
	
	public static int getLightData(SampleProvider cs, float[] cd) {
		cs.fetchSample(cd,0);
		int color = (int)cd[0] * 1000;
		
		return color;
	}
	
	public static double calc_distance(double x, double y, double target_x, double target_y) {
		return (Math.sqrt((x-target_x)*(x-target_x)+(y-target_y)*(y-target_y)));
	}
	
	/**
	 * This method is used to detect the color of the can, and update it to the detected_color
	 * @param myData This is the light sensor data provider
	 */
	public static void detect_color(SensorData myData) {
		sensorMotor.setSpeed(70);
		sensorMotor.rotate(250,true);
		LCD.clear();
		int[] color = {0,0,0,0,0};
		while(sensorMotor.isMoving()) {
			int result = ColorDetection.printColor(myData.RGBVal);
			color[result]++;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		//find out the color detected most times
		int index_number = 0;
		int largest = color[0];	
		for (int i = 0; i<color.length-1;i++) {
			if(largest<color[i]) {
				index_number = i;
				largest = color[i];
			}
		}
		sensorMotor.rotate(-250);
		detected_color = index_number;			//set to detected_color
	}
	
	public static void travelTo(double x, double y, boolean immediate) {
		
		//Reset motors
		for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] {leftmotor, rightmotor}) {
			motor.stop();
			motor.setAcceleration(1500);
		}
		
		//navigating = true;
		
		// We compute the turn angle
		double dX = x - odo.getXYT()[0]; //remaining x distance
		double dY = y - odo.getXYT()[1]; //remaining y distance
		double turn_angle = Math.atan2(dX, dY);
		
		// We rotate
		leftmotor.setSpeed(200);
		rightmotor.setSpeed(200);
		turnTo(Math.toDegrees(turn_angle));
		
		double distance = Math.hypot(dX, dY);
		
		// We move to waypoint
		leftmotor.setSpeed(200);
		rightmotor.setSpeed(200);
		leftmotor.rotate(convertDistance(WHEEL_RAD,distance),true);
		rightmotor.rotate(convertDistance(WHEEL_RAD,distance),immediate);
	}
	
/** 
 * Takes the new heading as input and make the robot turn to it
 * 
 * @param: double theta that represents an angle in radians
 */
	public static void turnTo(double theta) {
	
		double angle = getMinAngle(theta-odo.getXYT()[2]);
	
		leftmotor.rotate(convertAngle(WHEEL_RAD, TRACK, angle),true);
		rightmotor.rotate(-convertAngle(WHEEL_RAD, TRACK, angle),false);
	}

	/**
	 * Gets the smallest value (between 180 and -180) of an angle
	 */
	public static double getMinAngle(double angle){
		if (angle > 180) {  //Pi = 180 degrees
			angle -= 2*180; 
		} else if (angle < -180) {
			angle = angle + 2*180;
		}
		return angle;
	}

	/**
	 * 
	 * this method takes the radius of wheels and the distance that needs to be traveled, and calculate 
	 * the rotation of the wheels need to make to travel that distance
	 * 
	 * @param radius is the wheel radius
	 * @param distance is the distance needs to be traveled
	 * @return rotation of the wheels
	 */
	
	private static int convertDistance(double radius, double distance) {
	    return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	/**
	 * 
	 * this method take the radius of wheels, width of the robot and the angle needs to be rotated by the robot, 
	 * to calculate the rotation needs to make by wheels to turn a certain angle to a certain direction
	 * 
	 * @param radius is the radius of wheels
	 * @param width is the width of the robot
	 * @param angle is the angle needs to be turned by the robot
	 * @return rotation of wheels
	 */
	private static int convertAngle(double radius, double width, double angle) {
	    return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	
}
