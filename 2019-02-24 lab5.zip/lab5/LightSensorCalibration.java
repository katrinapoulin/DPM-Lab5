package ca.mcgill.ecse211.lab5;

import lejos.robotics.SampleProvider;

public class LightSensorCalibration extends Thread{
	
	
	
	
	SampleProvider LcolorSensor;
	SampleProvider RcolorSensor;
	float[] LcolorData;
	float[] RcolorData;
	private int Lcolor;
	private int Rcolor;
	
	public LightSensorCalibration(SampleProvider LcolorSensor, float[] LcolorData, SampleProvider RcolorSensor, float[] RcolorData) {
		this.LcolorSensor = LcolorSensor;
		this.RcolorSensor = RcolorSensor;
		this.LcolorData = LcolorData;
		this.RcolorData = RcolorData;
		//day = new String[3];
	}
	
	public void run(){
		while (true) {
			LcolorSensor.fetchSample(LcolorData, 0);			// We acquire data
			Lcolor = (int) (LcolorData[0] * 100); // We extract from buffer, and cast it to int 
			RcolorSensor.fetchSample(RcolorData, 0);			// We acquire data
			Rcolor = (int) (RcolorData[0] * 100); // We extract from buffer, and cast it to int 

			try {
				Thread.sleep(50);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public int[] getLightData() {
		
		
		return new int[] {Lcolor,Rcolor};
	}
}
