package ca.mcgill.ecse211.lab5;

import lejos.hardware.lcd.LCD;
import lejos.robotics.SampleProvider;
import ca.mcgill.ecse211.lab5.Lab5;

public class SensorData extends Thread{

	double []RGBdata= new double[3];
	double [] canScan = new double[3];
	private float[] colorData;
	SampleProvider colorSensor;
	double [] RGBVal;
	
	/**
	 * Method that sums up 10 samples of the Color Sensor's RGB values and computes the mean of R, G, and B values.
	 * 
	 * @return Array of mean R, G, B values
	 */
	
	 //get the sensor for color
	
	public SensorData() {
		
		this.colorSensor = Lab5.colorSensor;
		Lab5.colorSensor.setCurrentMode("RGB");//we setup the sensor in RGB mode to get the reflected light
	    this.colorData = new float[3];
	}
     
	public void run() {
		while(true) {
			try {
				RGBVal = getRGB();
				LCD.drawString("R:" + RGBVal[0],0,3);
				LCD.drawString("G:" + RGBVal[1],0,4);
				LCD.drawString("B:" + RGBVal[2],0,5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
    
    /**
     * This method calculate the normalized RGB value and return them as a double array
     * @return A double array of normalized RGB values
     * @throws InterruptedException
     */
	public double[] getRGB() throws InterruptedException {
		
		colorSensor.fetchSample(colorData, 0);
		double normalized_R =colorData[0]/Math.sqrt(colorData[0]*colorData[0]+colorData[1]*colorData[1]+colorData[2]*colorData[2]);
		double nomorlized_G =colorData[1]/Math.sqrt(colorData[0]*colorData[0]+colorData[1]*colorData[1]+colorData[2]*colorData[2]);
		double normalized_B =colorData[2]/Math.sqrt(colorData[0]*colorData[0]+colorData[1]*colorData[1]+colorData[2]*colorData[2]);
		
		return new double[] {normalized_R, nomorlized_G, normalized_B};
   }
}
