package ca.mcgill.ecse211.lab5;

import ca.mcgill.ecse211.lab5.Odometer;
import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.motor.EV3MediumRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

/**
 * ECSE 211 Lab 5 Can Searching
 * Group 20
 * 
 * @author Alfred Wang
 *
 * 2019 - 02 - 21
 */

public class Lab5 {
	private static final EV3LargeRegulatedMotor leftmotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));		//left motor
	private static final EV3LargeRegulatedMotor rightmotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B"));		//right motor
	private static final Port usPort = LocalEV3.get().getPort("S1");				//port for ultrasonic sensor
	private static final Port llcolorPort = LocalEV3.get().getPort("S2");			//port for localization color sensor
	public static final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S4")); 					//Light sensor for can color detection
	public static final EV3MediumRegulatedMotor sensorMotor = new EV3MediumRegulatedMotor(LocalEV3.get().getPort("C")); //Light sensor motor
	private static final double TRACK = 11.3;						//track of the robot
	private static final double WHEEL_RAD = 2.25;					//wheel radius of the robot
	static Odometer odo ;											//odometer
	private static int detected_color = 4;							//color of the can detected, originally set to 4 (other color)
	
	public static TextLCD lcd = LocalEV3.get().getTextLCD();		//lcd display
	
	static int LLx = 0;								//lower left x
	static int LLy = 0;								//lower left y
	static int URx = 4;								//upper right x
	static int URy = 4;								//upper right y
	static int target_color = 2;					//target color, (0 for blue, 1 for green, 2 for yellow, 3 for red, 4 for other)
	static boolean target_detected = false;			//boolean to know if the target is found
	
	static String[] color_base = {"BLUE", "GREEN", "YELLOW", "RED"};	//color data base
	
	/**
	 * The main method makes the robot to achieve the goal of lab 5, including localization, navigating to LL corner, find the target can and go to UR corner
	 * @param args
	 * @throws OdometerExceptions
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws OdometerExceptions, InterruptedException {
		
		@SuppressWarnings("resource")			//ultrasonic sensor will always be used, no need to turn it off
		SensorModes usSensor = new EV3UltrasonicSensor(usPort);				//get the ultrasonic sensor
		SampleProvider usValue = usSensor.getMode("Distance");			
		float[] usData = new float[usValue.sampleSize()];	
		
		@SuppressWarnings("resource")			//localization light sensor will always be used, no need to turn it off
		SensorModes llcolorSensor = new EV3ColorSensor(llcolorPort);		//get the color sensor
		SampleProvider colorValue = llcolorSensor.getMode("Red");
		float[] colorData = new float[colorValue.sampleSize()];		
		
		odo = Odometer.getOdometer(leftmotor, rightmotor, TRACK, WHEEL_RAD); 		//get odometer
		
		Display odometryDisplay = new Display(lcd); 								//get lcd display
		
		
		Button.waitForAnyPress();					//wait for press to start
	    
	    Thread odoThread = new Thread(odo);							//start the odometer
	    odoThread.start();
	    Thread odoDisplayThread = new Thread(odometryDisplay);		//display odometer data
	    odoDisplayThread.start();
	    USLocalizer usl = new USLocalizer(odo, usValue, usData, USLocalizer.LocalizationOption.FALLING_EDGE);
    	usl.Localize();
    	lcd.drawString("Finished US Localization", 0, 3);
	    turnTo(0);												//turn to 0 degree
	    Button.waitForAnyPress();								//wait for further instruction
	    lcd.drawString("CS Localization Started", 0, 4);		//indicate that light sensor localization is initiated
	    LightLocalizer lsl = new LightLocalizer (odo, colorValue, colorData);		//use light(color) sensor to localize
	    lsl.Localize();
	    travelTo(0,0,false);								//travel to 0,0
	    turnTo(0);											//turn to 0
	    lcd.drawString("Finished CS Localization", 0, 4);
	    
	    //navigation in the searching area starts----------------------------------------------------------------------------------------------------------
	    lcd.drawString("Press to start", 0, 0);
	    Button.waitForAnyPress();
	    travelTo(LLx,LLy,false);
	    turnTo(0);
	    
	    final UltrasonicPoller myusData = new UltrasonicPoller(usValue);
	    myusData.start();
	    SensorData mylsData = new SensorData();
		mylsData.start();
		
		//the following two loops help the robot to navigate through the entire searching area (still trying to find a better way)
	    for(int i = 0;i<=URx-LLx;i++) {								
	    	if(i%2==1) {
	    		for(int m=URy-LLy;m>=0;m--) {
	    			detect_can(myusData, mylsData, i, m);
	    			if(target_detected) break;
	    		}
	    	}else {
	    		for(int m=0;m<=URy-LLy;m++) {
	    			detect_can(myusData, mylsData, i, m);
	    			if(target_detected) break;
	    		}
	    	}
	    	if(target_detected) {
	    		lcd.drawString("target found", 0, 4);
	    	    break;
	    	}
	    }
	    
	    
	    //not finished, still need to travel to the UR corner
	    
	    Button.waitForAnyPress();
	    System.exit(0);
	    
	}
	
	/**
	 * 
	 * This method is used to detect whether or not there is a can in front of the robot
	 * 
	 * @param myData This is the ultrasonic sensor data provider
	 * @param mylsData This is the light sensor data provider
	 * @param x This is the x value of target location 
	 * @param y	This is the y value of target location
	 */
	public static void detect_can(UltrasonicPoller myData, SensorData mylsData, int x, int y) {
		
		odo.setMotorSpeeds(300);
		travelTo(x*30.48+LLx,y*30.48+LLy,true);
		while(leftmotor.isMoving()) {
			if(myData.getDistance()<=5) {				//if the ultrasonic sensor has a reading less than or equal to 5 cm, wo consider that there is a can and the robot stops and scan it
				odo.getMotor()[0].stop(true);
				odo.getMotor()[1].stop(true);
				lcd.clear();
				lcd.drawString("can detected", 0, 0);
				detect_color(mylsData);
				if(detected_color == target_color) {		//find out if this is the target can or not
					target_detected = true;
					Sound.beep();							//if yes, beep twice
					Sound.beep();
					lcd.drawString("detected_color: "+color_base[detected_color], 0, 5);
					break;
				}else {										//if no, beep once
					Sound.beep();
					lcd.drawString("detected_color: "+color_base[detected_color], 0, 5);
				}
				
				//go around the can
				leftmotor.rotate(convertAngle(WHEEL_RAD,TRACK,90),true);
				rightmotor.rotate(-convertAngle(WHEEL_RAD,TRACK,90),false);
				leftmotor.rotate(convertDistance(WHEEL_RAD,15),true);
				rightmotor.rotate(convertDistance(WHEEL_RAD,15),false);
			}
		}
	}
	
	/**
	 * This method is used to detect the color of the can, and update it to the detected_color
	 * @param myData This is the light sensor data provider
	 */
	public static void detect_color(SensorData myData) {
		sensorMotor.setSpeed(70);
		sensorMotor.rotate(250,true);
		LCD.clear();
		int[] color = {0,0,0,0,0};
		while(sensorMotor.isMoving()) {
			int result = ColorDetection.printColor(myData.RGBVal);
			color[result]++;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		//find out the color detected most times
		int index_number = 0;
		int largest = color[0];	
		for (int i = 0; i<color.length-1;i++) {
			if(largest<color[i]) {
				index_number = i;
				largest = color[i];
			}
		}
		sensorMotor.rotate(-250);
		detected_color = index_number;			//set to detected_color
	}
	
	/**
	 * 
	 * this method takes a coordinate as an input and make the robot to travel to that point
	 * 
	 * @param x This is the x position
	 * @param y This is the y position
	 */
static void travelTo(double x, double y, boolean immediate) {
		
		double pathX = x-odo.getXYT()[0];		//calculate x displacement 
		double pathY = y-odo.getXYT()[1];		//calculate y displacement
		double path = Math.hypot(pathX, pathY);		//calculate path length
		double pathAngle;
		if(pathX<0&&pathY>=0) {						//calculate turning angle
			pathAngle = 360-(Math.toDegrees(Math.atan2(pathY,pathX))-90);
		}else {
			pathAngle = 90-Math.toDegrees(Math.atan2(pathY,pathX));
		}
		
		turnTo(pathAngle);				//turn to the direction angle
		
		leftmotor.setSpeed(70);			//set speed
		rightmotor.setSpeed(70);
		
		leftmotor.rotate(convertDistance(WHEEL_RAD,path),true);		//go to the directed point
		rightmotor.rotate(convertDistance(WHEEL_RAD,path),immediate);
		
	}
	

/**
 * 
 * this method makes robot to turn to a specific direction
 * 
 * @param theta is the target direction
 */
	static void turnTo(double theta) {
		double turn_angle = theta-odo.getXYT()[2];			//calculate angle needs to turn
		if (turn_angle > 180) {
			turn_angle = turn_angle-360;
		}else if(turn_angle<(-180)) {
			turn_angle = turn_angle+360;
		}
		leftmotor.setSpeed(70);					//set motor speed
	    rightmotor.setSpeed(70);
	    if(turn_angle==360) {
	    	turn_angle = 0;
	    }
	    leftmotor.rotate(convertAngle(WHEEL_RAD, TRACK, turn_angle),true);			//turn to that direction
	    rightmotor.rotate(-convertAngle(WHEEL_RAD, TRACK, turn_angle),false);
	    
	    leftmotor.stop(true);							//stop the motor
	    rightmotor.stop();
	    
	}
	
	/**
	 * 
	 * this method takes the radius of wheels and the distance that needs to be traveled, and calculate 
	 * the rotation of the wheels need to make to travel that distance
	 * 
	 * @param radius is the wheel radius
	 * @param distance is the distance needs to be traveled
	 * @return rotation of the wheels
	 */
	
	private static int convertDistance(double radius, double distance) {
	    return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	/**
	 * 
	 * this method take the radius of wheels, width of the robot and the angle needs to be rotated by the robot, 
	 * to calculate the rotation needs to make by wheels to turn a certain angle to a certain direction
	 * 
	 * @param radius is the radius of wheels
	 * @param width is the width of the robot
	 * @param angle is the angle needs to be turned by the robot
	 * @return rotation of wheels
	 */
	private static int convertAngle(double radius, double width, double angle) {
	    return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	
}
