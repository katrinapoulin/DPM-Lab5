package ca.mcgill.ecse211.lab5;

import java.util.ArrayList;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class can_detection {
	
	static EV3LargeRegulatedMotor leftMotor;
	static EV3LargeRegulatedMotor rightMotor;
	Odometer odo;
	//private static final Port usPort = LocalEV3.get().getPort("S4");
	//public static final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S1")); //Ligh
	//static EV3UltrasonicSensor usSensor = new EV3UltrasonicSensor(usPort); // usSensor is the instance
	//SensorModes usSensor = new EV3UltrasonicSensor(usPort); // usSensor is the instance
	static SampleProvider usDistance = Lab5.usSensor.getMode("Distance"); // usDistance provides samples from
	float[] usData = new float[usDistance.sampleSize()];
	
	
	public can_detection(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, Odometer odo) {
		can_detection.leftMotor = leftMotor;
		can_detection.rightMotor = rightMotor;
		this.odo = odo;
	}
	
	public static ArrayList<int[]> detect () {
		ArrayList<int[]> position = new ArrayList<int []>();
		//Navigation nav = new Navigation(odo,leftMotor,rightMotor);
		leftMotor.setSpeed(80);
		rightMotor.setSpeed(80);
		leftMotor.rotate(convertAngle(90),true);
		rightMotor.rotate(-convertAngle(90),true);
		final UltrasonicPoller myData = new UltrasonicPoller(usDistance);
		myData.start();
		while(leftMotor.isMoving()) {
			int data = myData.getDistance();
			if(data>60&&data<75) {
				position.add(new int[]{1,2});
			}else if(data<50&&data>35) {
				position.add(new int[]{1,1});
			}else {
				
			}
		}
		
		return  position;
	}
	
	private static int convertDistance(double distance){
		return (int) (360*distance/(2*Math.PI*Lab5.WHEEL_RAD));
	}
	/**
	 * This method takes the difference between the new heading and the current heading as an input and 
	 * returns the total rotation that each wheel has to do to change the robot's heading
	 */
	private static int convertAngle(double angle){
		return convertDistance(Lab5.TRACK*angle/2);
	}

	
}
