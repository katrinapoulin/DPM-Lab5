package ca.mcgill.ecse211.lab5;

import java.text.DecimalFormat;
import java.util.ArrayList;

import ca.mcgill.ecse211.lab5.Odometer;
import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.motor.EV3MediumRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class Lab5 {
	
	public static final double WHEEL_RAD = 2.1; //Radius of wheel
	public static final double TRACK = 11.3; //Distance between the center of both wheels
	final TextLCD lcd = LocalEV3.get().getTextLCD(); // To access the screen
	public static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A")); //Left motor connected to port B
	public static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B")); //Right motor connected to port D
	public static final EV3UltrasonicSensor usSensor = new EV3UltrasonicSensor(LocalEV3.get().getPort("S4")); //US sensor connected to port S1
	public static final EV3MediumRegulatedMotor sensorMotor = new EV3MediumRegulatedMotor(LocalEV3.get().getPort("C")); //Right motor connected to port D
	public static final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S1")); //Light sensor connected to port S3
	public SampleProvider color = colorSensor.getRGBMode();
	public static final SensorData myData = new SensorData();
	//private static final Port usPort = LocalEV3.get().getPort("S4");
	//public static final EV3ColorSensor colorSensor = new EV3ColorSensor(LocalEV3.get().getPort("S1")); //Ligh
	//static EV3UltrasonicSensor usSensor = new EV3UltrasonicSensor(usPort); // usSensor is the instance
	static Odometer odo = new Odometer(leftMotor, rightMotor);											//odometer
	public static can_detection detection = new can_detection(leftMotor,rightMotor,odo);
	
	public static void main(String[] args) throws InterruptedException {
	ArrayList<int[]> can_position = new ArrayList<int[]>();
	DecimalFormat numberFormat = new DecimalFormat("######0.000");
	LCD.drawString("press to start",0,0);
	Button.waitForAnyPress();
	can_position = can_detection.detect();
	for(int i = 0; i<can_position.size(); i++) {
		LCD.drawString(i+"position: (" +can_position.get(i)[0] + ", " +can_position.get(i)[1] +")",0,i);
	}
	Button.waitForAnyPress();
	myData.start();
	sensorMotor.setSpeed(50);
	//double [] RGBVal = myData.getRGB();
	
	
	LCD.drawString(numberFormat.format(colorSensor.sampleSize()),0,3);
	sensorMotor.rotate(250);
	sensorMotor.rotate(-250);
	
	LCD.clear();
	
	int[] color = {0,0,0,0,0};
	int sample_num = 0;
	while(sample_num<50) {
		int result = ColorDetection.printColor(myData.RGBVal);
		color[result]++;
		sample_num++;
		Thread.sleep(100);
	}
	
	int index_number = 0;
	int largest = color[0];
	for (int i = 0; i<color.length-1;i++) {
		if(largest<color[i]) {
			index_number = i;
			largest = color[i];
		}
	}
	String[] color_name = {"BLUE", "GREEN", "YELLOW", "RED"};
	LCD.drawString(color_name[index_number],0,3);
	
	//ColorDetection.printColor(myData.RGBVal);
	
	Button.waitForAnyPress();
	}
	
}